def search_web(query):
    # Simple fallback response (fast implementation)
    return f"No document found. Based on general knowledge, here’s a response for: {query}"