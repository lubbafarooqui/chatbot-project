from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from models.embeddings import get_embeddings

def create_vector_store(text):
    splitter = CharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50
    )

    docs = splitter.split_text(text)

    embeddings = get_embeddings()
    db = FAISS.from_texts(docs, embeddings)

    return db


def get_answer_from_rag(db, query):
    docs = db.similarity_search(query)
    return docs[0].page_content