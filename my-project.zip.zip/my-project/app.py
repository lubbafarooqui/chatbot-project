import streamlit as st

st.title("🧠 Decision-Making AI Assistant")

st.write("App is running successfully!")

# Mode toggle
mode = st.selectbox("Response Mode", ["Concise", "Detailed"])

# File upload
uploaded_file = st.file_uploader("Upload a document (optional)")

# User input
query = st.text_input("Describe your situation:")

if query:
    st.write("You entered:", query)