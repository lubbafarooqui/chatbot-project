import gradio as gr
from groq import Groq

# Replace with your Groq API key
client = Groq(api_key="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")

def decision_bot(user_input, mode):
    prompt = f"""
    You are an intelligent decision-making assistant.

    Analyze the user's situation carefully.
    Compare options if present.
    Give pros and cons.
    Provide a final recommendation.

    User Query: {user_input}
    """

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}]
    )

    answer = response.choices[0].message.content

    if mode == "Concise":
        return answer[:150]
    return answer

interface = gr.Interface(
    fn=decision_bot,
    inputs=[
        gr.Textbox(label="Describe your situation"),
        gr.Radio(["Concise", "Detailed"], label="Response Mode")
    ],
    outputs="text",
    title="🧠 Decision-Making AI Assistant",
    description="AI assistant that helps you make better decisions."
)

interface.launch()