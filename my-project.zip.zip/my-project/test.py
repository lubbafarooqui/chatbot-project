import streamlit as st

st.title("HELLO TEST")

st.write("If you see this, Streamlit is working perfectly!")
